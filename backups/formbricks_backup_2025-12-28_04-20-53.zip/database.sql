--
-- PostgreSQL database dump
--

\restrict lBEXqOXmmHcfqcgI2pDAaGRTAniCfZPW0cCdhf3d0UIeP68bkq6qrnkoc3Hh66j

-- Dumped from database version 17.7 (Debian 17.7-3.pgdg12+1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-3.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionType" AS ENUM (
    'code',
    'noCode'
);


ALTER TYPE public."ActionType" OWNER TO postgres;

--
-- Name: ApiKeyPermission; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ApiKeyPermission" AS ENUM (
    'read',
    'write',
    'manage'
);


ALTER TYPE public."ApiKeyPermission" OWNER TO postgres;

--
-- Name: ContactAttributeType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ContactAttributeType" AS ENUM (
    'default',
    'custom'
);


ALTER TYPE public."ContactAttributeType" OWNER TO postgres;

--
-- Name: DataMigrationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DataMigrationStatus" AS ENUM (
    'pending',
    'applied',
    'failed'
);


ALTER TYPE public."DataMigrationStatus" OWNER TO postgres;

--
-- Name: EnvironmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EnvironmentType" AS ENUM (
    'production',
    'development'
);


ALTER TYPE public."EnvironmentType" OWNER TO postgres;

--
-- Name: IdentityProvider; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IdentityProvider" AS ENUM (
    'email',
    'github',
    'google',
    'azuread',
    'openid',
    'saml'
);


ALTER TYPE public."IdentityProvider" OWNER TO postgres;

--
-- Name: IntegrationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IntegrationType" AS ENUM (
    'googleSheets',
    'notion',
    'airtable',
    'slack'
);


ALTER TYPE public."IntegrationType" OWNER TO postgres;

--
-- Name: OrganizationRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrganizationRole" AS ENUM (
    'owner',
    'manager',
    'member',
    'billing'
);


ALTER TYPE public."OrganizationRole" OWNER TO postgres;

--
-- Name: PipelineTriggers; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PipelineTriggers" AS ENUM (
    'responseCreated',
    'responseUpdated',
    'responseFinished'
);


ALTER TYPE public."PipelineTriggers" OWNER TO postgres;

--
-- Name: ProjectTeamPermission; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProjectTeamPermission" AS ENUM (
    'read',
    'readWrite',
    'manage'
);


ALTER TYPE public."ProjectTeamPermission" OWNER TO postgres;

--
-- Name: ResponseQuotaLinkStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ResponseQuotaLinkStatus" AS ENUM (
    'screenedIn',
    'screenedOut'
);


ALTER TYPE public."ResponseQuotaLinkStatus" OWNER TO postgres;

--
-- Name: SurveyAttributeFilterCondition; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SurveyAttributeFilterCondition" AS ENUM (
    'equals',
    'notEquals'
);


ALTER TYPE public."SurveyAttributeFilterCondition" OWNER TO postgres;

--
-- Name: SurveyQuotaAction; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SurveyQuotaAction" AS ENUM (
    'endSurvey',
    'continueSurvey'
);


ALTER TYPE public."SurveyQuotaAction" OWNER TO postgres;

--
-- Name: SurveyStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SurveyStatus" AS ENUM (
    'draft',
    'inProgress',
    'paused',
    'completed'
);


ALTER TYPE public."SurveyStatus" OWNER TO postgres;

--
-- Name: SurveyType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SurveyType" AS ENUM (
    'link',
    'app'
);


ALTER TYPE public."SurveyType" OWNER TO postgres;

--
-- Name: TeamUserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TeamUserRole" AS ENUM (
    'admin',
    'contributor'
);


ALTER TYPE public."TeamUserRole" OWNER TO postgres;

--
-- Name: WebhookSource; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WebhookSource" AS ENUM (
    'user',
    'zapier',
    'make',
    'n8n',
    'activepieces'
);


ALTER TYPE public."WebhookSource" OWNER TO postgres;

--
-- Name: WidgetPlacement; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WidgetPlacement" AS ENUM (
    'bottomLeft',
    'bottomRight',
    'topLeft',
    'topRight',
    'center'
);


ALTER TYPE public."WidgetPlacement" OWNER TO postgres;

--
-- Name: displayOptions; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."displayOptions" AS ENUM (
    'displayOnce',
    'displayMultiple',
    'displaySome',
    'respondMultiple'
);


ALTER TYPE public."displayOptions" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    access_token text,
    refresh_token text,
    expires_at integer,
    ext_expires_in integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: ActionClass; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActionClass" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    type public."ActionType" NOT NULL,
    key text,
    "noCodeConfig" jsonb,
    "environmentId" text NOT NULL
);


ALTER TABLE public."ActionClass" OWNER TO postgres;

--
-- Name: ApiKey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApiKey" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdBy" text,
    "lastUsedAt" timestamp(3) without time zone,
    label text NOT NULL,
    "hashedKey" text NOT NULL,
    "lookupHash" text,
    "organizationId" text NOT NULL,
    "organizationAccess" jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public."ApiKey" OWNER TO postgres;

--
-- Name: ApiKeyEnvironment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApiKeyEnvironment" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "apiKeyId" text NOT NULL,
    "environmentId" text NOT NULL,
    permission public."ApiKeyPermission" NOT NULL
);


ALTER TABLE public."ApiKeyEnvironment" OWNER TO postgres;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contact" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "environmentId" text NOT NULL
);


ALTER TABLE public."Contact" OWNER TO postgres;

--
-- Name: ContactAttribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ContactAttribute" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "attributeKeyId" text NOT NULL,
    "contactId" text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."ContactAttribute" OWNER TO postgres;

--
-- Name: ContactAttributeKey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ContactAttributeKey" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "isUnique" boolean DEFAULT false NOT NULL,
    key text NOT NULL,
    name text,
    description text,
    type public."ContactAttributeType" DEFAULT 'custom'::public."ContactAttributeType" NOT NULL,
    "environmentId" text NOT NULL
);


ALTER TABLE public."ContactAttributeKey" OWNER TO postgres;

--
-- Name: DataMigration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DataMigration" (
    id text NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished_at timestamp(3) without time zone,
    name text NOT NULL,
    status public."DataMigrationStatus" NOT NULL
);


ALTER TABLE public."DataMigration" OWNER TO postgres;

--
-- Name: Display; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Display" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "surveyId" text NOT NULL,
    "contactId" text
);


ALTER TABLE public."Display" OWNER TO postgres;

--
-- Name: Environment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Environment" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    type public."EnvironmentType" NOT NULL,
    "projectId" text NOT NULL,
    "appSetupCompleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Environment" OWNER TO postgres;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Integration" (
    id text NOT NULL,
    type public."IntegrationType" NOT NULL,
    "environmentId" text NOT NULL,
    config jsonb NOT NULL
);


ALTER TABLE public."Integration" OWNER TO postgres;

--
-- Name: Invite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Invite" (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    "organizationId" text NOT NULL,
    "creatorId" text NOT NULL,
    "acceptorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    role public."OrganizationRole" DEFAULT 'member'::public."OrganizationRole" NOT NULL,
    "teamIds" text[] DEFAULT ARRAY[]::text[]
);


ALTER TABLE public."Invite" OWNER TO postgres;

--
-- Name: Language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Language" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    code text NOT NULL,
    alias text,
    "projectId" text NOT NULL
);


ALTER TABLE public."Language" OWNER TO postgres;

--
-- Name: Membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Membership" (
    "organizationId" text NOT NULL,
    "userId" text NOT NULL,
    accepted boolean DEFAULT false NOT NULL,
    role public."OrganizationRole" DEFAULT 'member'::public."OrganizationRole" NOT NULL
);


ALTER TABLE public."Membership" OWNER TO postgres;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    billing jsonb NOT NULL,
    whitelabel jsonb DEFAULT '{}'::jsonb NOT NULL,
    "isAIEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Organization" OWNER TO postgres;

--
-- Name: Project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "organizationId" text NOT NULL,
    styling jsonb DEFAULT '{"allowStyleOverwrite": true}'::jsonb NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    "recontactDays" integer DEFAULT 7 NOT NULL,
    "linkSurveyBranding" boolean DEFAULT true NOT NULL,
    "inAppSurveyBranding" boolean DEFAULT true NOT NULL,
    placement public."WidgetPlacement" DEFAULT 'bottomRight'::public."WidgetPlacement" NOT NULL,
    "clickOutsideClose" boolean DEFAULT true NOT NULL,
    "darkOverlay" boolean DEFAULT false NOT NULL,
    logo jsonb
);


ALTER TABLE public."Project" OWNER TO postgres;

--
-- Name: ProjectTeam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProjectTeam" (
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "projectId" text NOT NULL,
    "teamId" text NOT NULL,
    permission public."ProjectTeamPermission" DEFAULT 'read'::public."ProjectTeamPermission" NOT NULL
);


ALTER TABLE public."ProjectTeam" OWNER TO postgres;

--
-- Name: Response; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Response" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished boolean DEFAULT false NOT NULL,
    "surveyId" text NOT NULL,
    "contactId" text,
    "endingId" text,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    variables jsonb DEFAULT '{}'::jsonb NOT NULL,
    ttc jsonb DEFAULT '{}'::jsonb NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    "contactAttributes" jsonb,
    "singleUseId" text,
    language text,
    "displayId" text
);


ALTER TABLE public."Response" OWNER TO postgres;

--
-- Name: ResponseQuotaLink; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResponseQuotaLink" (
    "responseId" text NOT NULL,
    "quotaId" text NOT NULL,
    status public."ResponseQuotaLinkStatus" NOT NULL
);


ALTER TABLE public."ResponseQuotaLink" OWNER TO postgres;

--
-- Name: Segment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Segment" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    title text NOT NULL,
    description text,
    "isPrivate" boolean DEFAULT true NOT NULL,
    filters jsonb DEFAULT '[]'::jsonb NOT NULL,
    "environmentId" text NOT NULL
);


ALTER TABLE public."Segment" OWNER TO postgres;

--
-- Name: Survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Survey" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "redirectUrl" text,
    type public."SurveyType" DEFAULT 'app'::public."SurveyType" NOT NULL,
    "environmentId" text NOT NULL,
    "createdBy" text,
    status public."SurveyStatus" DEFAULT 'draft'::public."SurveyStatus" NOT NULL,
    "welcomeCard" jsonb DEFAULT '{"enabled": false}'::jsonb NOT NULL,
    questions jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocks jsonb[] DEFAULT ARRAY[]::jsonb[],
    endings jsonb[] DEFAULT ARRAY[]::jsonb[],
    "hiddenFields" jsonb DEFAULT '{"enabled": false}'::jsonb NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    "displayOption" public."displayOptions" DEFAULT 'displayOnce'::public."displayOptions" NOT NULL,
    "recontactDays" integer,
    "displayLimit" integer,
    "inlineTriggers" jsonb,
    "autoClose" integer,
    "autoComplete" integer,
    delay integer DEFAULT 0 NOT NULL,
    "surveyClosedMessage" jsonb,
    "segmentId" text,
    "projectOverwrites" jsonb,
    styling jsonb,
    "singleUse" jsonb DEFAULT '{"enabled": false, "isEncrypted": true}'::jsonb,
    "isVerifyEmailEnabled" boolean DEFAULT false NOT NULL,
    "isSingleResponsePerEmailEnabled" boolean DEFAULT false NOT NULL,
    "isBackButtonHidden" boolean DEFAULT false NOT NULL,
    pin text,
    "displayPercentage" numeric(65,30),
    "showLanguageSwitch" boolean,
    recaptcha jsonb DEFAULT '{"enabled": false, "threshold": 0.1}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public."Survey" OWNER TO postgres;

--
-- Name: SurveyAttributeFilter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyAttributeFilter" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "attributeKeyId" text NOT NULL,
    "surveyId" text NOT NULL,
    condition public."SurveyAttributeFilterCondition" NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."SurveyAttributeFilter" OWNER TO postgres;

--
-- Name: SurveyFollowUp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyFollowUp" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "surveyId" text NOT NULL,
    name text NOT NULL,
    trigger jsonb NOT NULL,
    action jsonb NOT NULL
);


ALTER TABLE public."SurveyFollowUp" OWNER TO postgres;

--
-- Name: SurveyLanguage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyLanguage" (
    "languageId" text NOT NULL,
    "surveyId" text NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public."SurveyLanguage" OWNER TO postgres;

--
-- Name: SurveyQuota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyQuota" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "surveyId" text NOT NULL,
    name text NOT NULL,
    "limit" integer NOT NULL,
    logic jsonb DEFAULT '{}'::jsonb NOT NULL,
    action public."SurveyQuotaAction" NOT NULL,
    "endingCardId" text,
    "countPartialSubmissions" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."SurveyQuota" OWNER TO postgres;

--
-- Name: SurveyTrigger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SurveyTrigger" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "surveyId" text NOT NULL,
    "actionClassId" text NOT NULL
);


ALTER TABLE public."SurveyTrigger" OWNER TO postgres;

--
-- Name: Tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tag" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "environmentId" text NOT NULL
);


ALTER TABLE public."Tag" OWNER TO postgres;

--
-- Name: TagsOnResponses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TagsOnResponses" (
    "responseId" text NOT NULL,
    "tagId" text NOT NULL
);


ALTER TABLE public."TagsOnResponses" OWNER TO postgres;

--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "organizationId" text NOT NULL
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: TeamUser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TeamUser" (
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    "teamId" text NOT NULL,
    "userId" text NOT NULL,
    role public."TeamUserRole" NOT NULL
);


ALTER TABLE public."TeamUser" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified timestamp(3) without time zone,
    "twoFactorSecret" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "backupCodes" text,
    password text,
    "identityProvider" public."IdentityProvider" DEFAULT 'email'::public."IdentityProvider" NOT NULL,
    "identityProviderAccountId" text,
    "groupId" text,
    "notificationSettings" jsonb DEFAULT '{}'::jsonb NOT NULL,
    locale text DEFAULT 'en-US'::text NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: Webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Webhook" (
    id text NOT NULL,
    name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    url text NOT NULL,
    source public."WebhookSource" DEFAULT 'user'::public."WebhookSource" NOT NULL,
    "environmentId" text NOT NULL,
    triggers public."PipelineTriggers"[],
    "surveyIds" text[]
);


ALTER TABLE public."Webhook" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: analytics_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_logs (
    id text DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'success'::text NOT NULL
);


ALTER TABLE public.analytics_logs OWNER TO postgres;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, created_at, updated_at, "userId", type, provider, "providerAccountId", access_token, refresh_token, expires_at, ext_expires_in, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: ActionClass; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActionClass" (id, created_at, updated_at, name, description, type, key, "noCodeConfig", "environmentId") FROM stdin;
\.


--
-- Data for Name: ApiKey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApiKey" (id, "createdAt", "createdBy", "lastUsedAt", label, "hashedKey", "lookupHash", "organizationId", "organizationAccess") FROM stdin;
\.


--
-- Data for Name: ApiKeyEnvironment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApiKeyEnvironment" (id, "createdAt", "updatedAt", "apiKeyId", "environmentId", permission) FROM stdin;
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contact" (id, created_at, updated_at, "environmentId") FROM stdin;
\.


--
-- Data for Name: ContactAttribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ContactAttribute" (id, created_at, updated_at, "attributeKeyId", "contactId", value) FROM stdin;
\.


--
-- Data for Name: ContactAttributeKey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ContactAttributeKey" (id, created_at, updated_at, "isUnique", key, name, description, type, "environmentId") FROM stdin;
cmjoox8wy0005r1013kels45u	2025-12-27 19:25:24.706	2025-12-27 19:25:24.706	t	userId	User Id	The user id of a contact	default	cmjoox8wy0004r101s764g8vk
cmjoox8wy0006r101pv4zfa4z	2025-12-27 19:25:24.706	2025-12-27 19:25:24.706	t	email	Email	The email of a contact	default	cmjoox8wy0004r101s764g8vk
cmjoox8wy0007r101fqv69g3l	2025-12-27 19:25:24.706	2025-12-27 19:25:24.706	f	firstName	First Name	Your contact's first name	default	cmjoox8wy0004r101s764g8vk
cmjoox8wy0008r101au79cqxp	2025-12-27 19:25:24.706	2025-12-27 19:25:24.706	f	lastName	Last Name	Your contact's last name	default	cmjoox8wy0004r101s764g8vk
cmjoox8x5000ar101psys2svt	2025-12-27 19:25:24.713	2025-12-27 19:25:24.713	t	userId	User Id	The user id of a contact	default	cmjoox8x50009r101ndv66bkz
cmjoox8x5000br101ws2hwv2q	2025-12-27 19:25:24.713	2025-12-27 19:25:24.713	t	email	Email	The email of a contact	default	cmjoox8x50009r101ndv66bkz
cmjoox8x5000cr101zrt9rkp3	2025-12-27 19:25:24.713	2025-12-27 19:25:24.713	f	firstName	First Name	Your contact's first name	default	cmjoox8x50009r101ndv66bkz
cmjoox8x5000dr101dy6f8aah	2025-12-27 19:25:24.713	2025-12-27 19:25:24.713	f	lastName	Last Name	Your contact's last name	default	cmjoox8x50009r101ndv66bkz
\.


--
-- Data for Name: DataMigration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DataMigration" (id, started_at, finished_at, name, status) FROM stdin;
\.


--
-- Data for Name: Display; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Display" (id, created_at, updated_at, "surveyId", "contactId") FROM stdin;
\.


--
-- Data for Name: Environment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Environment" (id, created_at, updated_at, type, "projectId", "appSetupCompleted") FROM stdin;
cmjoox8wy0004r101s764g8vk	2025-12-27 19:25:24.706	2025-12-27 19:25:24.719	development	cmjoox8wp0003r1010lvcv06m	f
cmjoox8x50009r101ndv66bkz	2025-12-27 19:25:24.713	2025-12-27 19:25:24.719	production	cmjoox8wp0003r1010lvcv06m	f
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Integration" (id, type, "environmentId", config) FROM stdin;
\.


--
-- Data for Name: Invite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Invite" (id, email, name, "organizationId", "creatorId", "acceptorId", "createdAt", "expiresAt", role, "teamIds") FROM stdin;
\.


--
-- Data for Name: Language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Language" (id, created_at, updated_at, code, alias, "projectId") FROM stdin;
\.


--
-- Data for Name: Membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Membership" ("organizationId", "userId", accepted, role) FROM stdin;
cmjoowzwc0001r101eftmbmaa	cmjoowzw10000r101oxaynapq	t	owner
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Organization" (id, created_at, updated_at, name, billing, whitelabel, "isAIEnabled") FROM stdin;
cmjoowzwc0001r101eftmbmaa	2025-12-27 19:25:13.02	2025-12-27 19:25:13.02	steven au's Organization	{"plan": "free", "limits": {"monthly": {"miu": 2000, "responses": 1500}, "projects": 3}, "period": "monthly", "periodStart": "2025-12-27T19:25:13.019Z", "stripeCustomerId": null}	{}	f
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Project" (id, created_at, updated_at, name, "organizationId", styling, config, "recontactDays", "linkSurveyBranding", "inAppSurveyBranding", placement, "clickOutsideClose", "darkOverlay", logo) FROM stdin;
cmjoox8wp0003r1010lvcv06m	2025-12-27 19:25:24.698	2025-12-27 19:25:24.698	Quann	cmjoowzwc0001r101eftmbmaa	{"brandColor": {"light": "#64748b"}, "allowStyleOverwrite": true}	{"channel": null, "industry": null}	7	t	t	bottomRight	t	f	\N
\.


--
-- Data for Name: ProjectTeam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProjectTeam" (created_at, updated_at, "projectId", "teamId", permission) FROM stdin;
\.


--
-- Data for Name: Response; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Response" (id, created_at, updated_at, finished, "surveyId", "contactId", "endingId", data, variables, ttc, meta, "contactAttributes", "singleUseId", language, "displayId") FROM stdin;
\.


--
-- Data for Name: ResponseQuotaLink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResponseQuotaLink" ("responseId", "quotaId", status) FROM stdin;
\.


--
-- Data for Name: Segment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Segment" (id, created_at, updated_at, title, description, "isPrivate", filters, "environmentId") FROM stdin;
\.


--
-- Data for Name: Survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Survey" (id, created_at, updated_at, name, "redirectUrl", type, "environmentId", "createdBy", status, "welcomeCard", questions, blocks, endings, "hiddenFields", variables, "displayOption", "recontactDays", "displayLimit", "inlineTriggers", "autoClose", "autoComplete", delay, "surveyClosedMessage", "segmentId", "projectOverwrites", styling, "singleUse", "isVerifyEmailEnabled", "isSingleResponsePerEmailEnabled", "isBackButtonHidden", pin, "displayPercentage", "showLanguageSwitch", recaptcha, metadata) FROM stdin;
cmjpjdx3v0002lc017lpgj0r4	2025-12-28 09:38:11.036	2025-12-28 10:19:12.923	Start from scratch	\N	link	cmjoox8x50009r101ndv66bkz	cmjoowzw10000r101oxaynapq	inProgress	{"enabled": false, "headline": {"default": "Welcome!"}, "subheader": {"default": "Thanks for providing your feedback - let's go!"}, "buttonLabel": {"default": "Next"}, "timeToFinish": false, "showResponseCount": false}	[]	{"{\\"id\\": \\"wxgynipkrtqq9qufc9vmrrp9\\", \\"name\\": \\"Block 1\\", \\"elements\\": [{\\"id\\": \\"l1cg7glr6x8n8put1c3zlfyw\\", \\"type\\": \\"openText\\", \\"headline\\": {\\"default\\": \\"<p class=\\\\\\"fb-editor-paragraph\\\\\\"><b><strong class=\\\\\\"fb-editor-text-bold\\\\\\" style=\\\\\\"\\\\\\">What would you like to know?</strong></b></p>\\"}, \\"required\\": true, \\"charLimit\\": {\\"enabled\\": false}, \\"inputType\\": \\"text\\", \\"placeholder\\": {\\"default\\": \\"Type your answer here...;';'l';'\\"}}], \\"buttonLabel\\": {\\"default\\": \\"Next\\"}}","{\\"id\\": \\"akbox3wzhxc399d01eyfyeby\\", \\"name\\": \\"Block 2\\", \\"elements\\": [{\\"id\\": \\"myvjgu8n0gcjhvgo2unl3k4u\\", \\"type\\": \\"fileUpload\\", \\"headline\\": {\\"default\\": \\"<p class=\\\\\\"fb-editor-paragraph\\\\\\"><span style=\\\\\\"\\\\\\">hjkhjkhjk</span></p>\\"}, \\"required\\": false, \\"allowMultipleFiles\\": false}, {\\"id\\": \\"n0zfrmq4h82e75ja88mjsozx\\", \\"zip\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"Zip\\"}}, \\"city\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"City\\"}}, \\"type\\": \\"address\\", \\"state\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"State\\"}}, \\"country\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"Country\\"}}, \\"headline\\": {\\"default\\": \\"<p class=\\\\\\"fb-editor-paragraph\\\\\\"><span style=\\\\\\"\\\\\\">hjkhjk</span></p>\\"}, \\"required\\": true, \\"addressLine1\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"Address Line 1\\"}}, \\"addressLine2\\": {\\"show\\": true, \\"required\\": true, \\"placeholder\\": {\\"default\\": \\"Address Line 2\\"}}}], \\"buttonLabel\\": {\\"default\\": \\"\\"}, \\"backButtonLabel\\": {\\"default\\": \\"\\"}}","{\\"id\\": \\"k5d3ul17qt3xlk0f5j12xhfu\\", \\"name\\": \\"Block 3\\", \\"elements\\": [{\\"id\\": \\"d4u3hjvcdl41y4fjzy6nv1hn\\", \\"type\\": \\"rating\\", \\"range\\": 5, \\"scale\\": \\"star\\", \\"headline\\": {\\"default\\": \\"<p class=\\\\\\"fb-editor-paragraph\\\\\\"><span style=\\\\\\"\\\\\\">hjkhj</span></p>\\"}, \\"required\\": false, \\"lowerLabel\\": {\\"default\\": \\"Not good\\"}, \\"upperLabel\\": {\\"default\\": \\"Very good\\"}, \\"isColorCodingEnabled\\": false}], \\"buttonLabel\\": {\\"default\\": \\"\\"}, \\"backButtonLabel\\": {\\"default\\": \\"\\"}}","{\\"id\\": \\"ld48xtwvqx77k4m6k3427xp9\\", \\"name\\": \\"Block 4\\", \\"elements\\": [{\\"id\\": \\"ayvi17x72i23rozmsrjboa9k\\", \\"type\\": \\"multipleChoiceSingle\\", \\"choices\\": [{\\"id\\": \\"gg67tbi8cc1f8ado6po4v4ql\\", \\"label\\": {\\"default\\": \\"hjkhj\\"}}, {\\"id\\": \\"s02751wkkxujhirm3azil1np\\", \\"label\\": {\\"default\\": \\"khjk\\"}}], \\"headline\\": {\\"default\\": \\"<p class=\\\\\\"fb-editor-paragraph\\\\\\"><span style=\\\\\\"\\\\\\">hjkjhkhjk</span></p>\\"}, \\"required\\": false, \\"shuffleOption\\": \\"none\\"}], \\"buttonLabel\\": {\\"default\\": \\"\\"}, \\"backButtonLabel\\": {\\"default\\": \\"\\"}}"}	{"{\\"id\\": \\"vw6zh0x6okbc6t96wsp38tln\\", \\"type\\": \\"endScreen\\", \\"headline\\": {\\"default\\": \\"Thank you!\\"}, \\"subheader\\": {\\"default\\": \\"We appreciate your feedback.\\"}, \\"buttonLink\\": \\"https://formbricks.com\\", \\"buttonLabel\\": {\\"default\\": \\"Create your own Survey\\"}}"}	{"enabled": true, "fieldIds": []}	[]	displayOnce	\N	\N	\N	\N	\N	0	null	\N	null	null	{"enabled": false, "isEncrypted": true}	f	f	f	\N	\N	\N	{"enabled": false, "threshold": 0.1}	{}
\.


--
-- Data for Name: SurveyAttributeFilter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyAttributeFilter" (id, created_at, updated_at, "attributeKeyId", "surveyId", condition, value) FROM stdin;
\.


--
-- Data for Name: SurveyFollowUp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyFollowUp" (id, created_at, updated_at, "surveyId", name, trigger, action) FROM stdin;
\.


--
-- Data for Name: SurveyLanguage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyLanguage" ("languageId", "surveyId", "default", enabled) FROM stdin;
\.


--
-- Data for Name: SurveyQuota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyQuota" (id, created_at, updated_at, "surveyId", name, "limit", logic, action, "endingCardId", "countPartialSubmissions") FROM stdin;
\.


--
-- Data for Name: SurveyTrigger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SurveyTrigger" (id, created_at, updated_at, "surveyId", "actionClassId") FROM stdin;
\.


--
-- Data for Name: Tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tag" (id, created_at, updated_at, name, "environmentId") FROM stdin;
\.


--
-- Data for Name: TagsOnResponses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TagsOnResponses" ("responseId", "tagId") FROM stdin;
\.


--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, created_at, updated_at, name, "organizationId") FROM stdin;
\.


--
-- Data for Name: TeamUser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TeamUser" (created_at, updated_at, "teamId", "userId", role) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, created_at, updated_at, name, email, email_verified, "twoFactorSecret", "twoFactorEnabled", "backupCodes", password, "identityProvider", "identityProviderAccountId", "groupId", "notificationSettings", locale, "lastLoginAt", "isActive") FROM stdin;
cmjoowzw10000r101oxaynapq	2025-12-27 19:25:13.009	2025-12-27 19:36:05.825	steven au	stevenau281@gmail.com	\N	\N	f	\N	$2b$12$IdG4eh18sS4YE7a7q3saVO4dMrDRDlkhZXstpvMwQ/pGMLbnYaWby	email	\N	\N	{"alert": {}, "unsubscribedOrganizationIds": ["cmjoowzwc0001r101eftmbmaa"]}	en-US	2025-12-27 19:36:05.824	t
\.


--
-- Data for Name: Webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Webhook" (id, name, created_at, updated_at, url, source, "environmentId", triggers, "surveyIds") FROM stdin;
cmjoqdz0w000jr101us1ggpkd	n8n	2025-12-27 20:06:24.656	2025-12-27 20:06:24.656	https://n8n.nhax.app/webhook/webhook	user	cmjoox8x50009r101ndv66bkz	{responseCreated,responseUpdated,responseFinished}	{}
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
8c31aa78-975c-481c-a0c3-70c22dccac1d	4fb5177fcdcfb62c4c85a7c4c197029f5905a920e2a470988e652449108624f1	2025-12-27 17:58:14.311608+00	20251227175814_add_mcp	\N	\N	2025-12-27 17:58:14.184599+00	1
6d03f26f-97ef-4d33-85ff-e3ca376b4ddd	9a879557bd62c5a3ad308a740db3025c4f7247e9f3f201466c62348f11903076	2025-12-27 18:09:04.931453+00	20251227180904_add_analytics_log	\N	\N	2025-12-27 18:09:04.919131+00	1
76d60269-80eb-4b81-a3f1-d681580310f2	d067b7adb65480b7e2b25e34758cd5d42be8cd90382f66a9185f120d48c6990f	2025-12-27 18:11:57.159625+00	20251227181157_update_analytics_log_id	\N	\N	2025-12-27 18:11:57.149466+00	1
cc762817-b2cf-4a72-b38c-db915ab26aee	df81be24131b2d7d01c59c62b52df386a2e75a0e8ca204c820806b81f496cd7e	2025-12-27 18:29:06.636217+00	20251227182906_add_analytics_indexes	\N	\N	2025-12-27 18:29:06.590076+00	1
\.


--
-- Data for Name: analytics_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_logs (id, created_at, event, payload, status) FROM stdin;
3e4bfd9e-9705-45c4-ab5a-eb8cb2fe985a	2025-12-27 18:14:31.23	test_response_finished	{"source": "test_script", "response": {"id": "resp-456", "data": {"q1": "Yes", "q2": "5 stars"}, "finished": true}, "surveyId": "test-survey-123", "timestamp": "2025-12-27T18:14:31.070Z"}	success
5d6f1061-400f-4470-bc67-9375d8e088fe	2025-12-27 18:25:25.276	test_response_finished	{"source": "test_script", "response": {"id": "resp-456", "data": {"q1": "Yes", "q2": "5 stars"}, "finished": true}, "surveyId": "test-survey-123", "timestamp": "2025-12-27T18:25:25.252Z"}	success
4498c5b4-6376-4cfc-803b-2cd320e578a6	2025-12-27 19:57:42.561	test_event	{}	
4538e12d-7e63-4834-a9ac-ddfa9b9fec42	2025-12-27 20:02:39.2	testEndpoint	{"event": "testEndpoint"}	
6c62be2a-62d0-4794-b4c9-67ee66b7d75b	2025-12-27 20:03:59.47	testEndpoint	{"event": "testEndpoint"}	
f903bed0-d7c4-404a-9a37-77357dee4085	2025-12-27 20:06:10.745	testEndpoint	{"event": "testEndpoint"}	
64db9721-a2dc-4acf-afdd-046fcd9a0025	2025-12-27 20:06:24.617	testEndpoint	{"event": "testEndpoint"}	
a11112d2-dfff-4514-98cb-7d5aac744527	2025-12-27 20:06:45.997	responseCreated	{"data": {"id": "cmjoqef5y000lr1016n6xn89o", "ttc": {"gd7sgb0v5ukpswtubihwbzco": 12006.80000001192}, "data": {"gd7sgb0v5ukpswtubihwbzco": 5}, "meta": {"url": "https://webhook.nhax.app/s/cmjooxabi000er101ofthxco2", "country": "US", "userAgent": {"os": "Windows", "device": "desktop", "browser": "Chrome"}}, "tags": [], "survey": {"type": "link", "title": "Form Survey", "status": "inProgress", "createdAt": "2025-12-27T19:25:26.526Z", "updatedAt": "2025-12-27T19:40:52.331Z"}, "contact": null, "endingId": null, "finished": false, "language": null, "surveyId": "cmjooxabi000er101ofthxco2", "createdAt": "2025-12-27T20:06:45.574Z", "displayId": "cmjoqeagb000kr101mnsulj9h", "updatedAt": "2025-12-27T20:06:45.574Z", "variables": {}, "singleUseId": null, "contactAttributes": null}, "event": "responseCreated", "webhookId": "cmjoqdz0w000jr101us1ggpkd"}	
a2d3f943-3928-4dea-ae43-2b8d131faf52	2025-12-27 20:06:49.26	responseUpdated	{"data": {"id": "cmjoqef5y000lr1016n6xn89o", "ttc": {"_total": 13987.90000000596, "emlkopd0tk1rg76i3lv2dobi": 1981.09999999404, "gd7sgb0v5ukpswtubihwbzco": 12006.80000001192}, "data": {"emlkopd0tk1rg76i3lv2dobi": "asdasd", "gd7sgb0v5ukpswtubihwbzco": 5}, "meta": {"url": "https://webhook.nhax.app/s/cmjooxabi000er101ofthxco2", "country": "US", "userAgent": {"os": "Windows", "device": "desktop", "browser": "Chrome"}}, "tags": [], "survey": {"type": "link", "title": "Form Survey", "status": "inProgress", "createdAt": "2025-12-27T19:25:26.526Z", "updatedAt": "2025-12-27T19:40:52.331Z"}, "contact": null, "endingId": null, "finished": true, "language": null, "surveyId": "cmjooxabi000er101ofthxco2", "createdAt": "2025-12-27T20:06:45.574Z", "displayId": "cmjoqeagb000kr101mnsulj9h", "updatedAt": "2025-12-27T20:06:48.976Z", "variables": {}, "singleUseId": null, "contactAttributes": null}, "event": "responseUpdated", "webhookId": "cmjoqdz0w000jr101us1ggpkd"}	
3fa245c9-5e04-4852-9601-e08691af7931	2025-12-27 20:06:49.411	responseFinished	{"data": {"id": "cmjoqef5y000lr1016n6xn89o", "ttc": {"_total": 13987.90000000596, "emlkopd0tk1rg76i3lv2dobi": 1981.09999999404, "gd7sgb0v5ukpswtubihwbzco": 12006.80000001192}, "data": {"emlkopd0tk1rg76i3lv2dobi": "asdasd", "gd7sgb0v5ukpswtubihwbzco": 5}, "meta": {"url": "https://webhook.nhax.app/s/cmjooxabi000er101ofthxco2", "country": "US", "userAgent": {"os": "Windows", "device": "desktop", "browser": "Chrome"}}, "tags": [], "survey": {"type": "link", "title": "Form Survey", "status": "inProgress", "createdAt": "2025-12-27T19:25:26.526Z", "updatedAt": "2025-12-27T19:40:52.331Z"}, "contact": null, "endingId": null, "finished": true, "language": null, "surveyId": "cmjooxabi000er101ofthxco2", "createdAt": "2025-12-27T20:06:45.574Z", "displayId": "cmjoqeagb000kr101mnsulj9h", "updatedAt": "2025-12-27T20:06:48.976Z", "variables": {}, "singleUseId": null, "contactAttributes": null}, "event": "responseFinished", "webhookId": "cmjoqdz0w000jr101us1ggpkd"}	
8679df20-566d-4f41-8096-b8a3ef6242d3	2025-12-27 21:36:44.087	testEndpoint	{"event": "testEndpoint"}	
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: ActionClass ActionClass_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionClass"
    ADD CONSTRAINT "ActionClass_pkey" PRIMARY KEY (id);


--
-- Name: ApiKeyEnvironment ApiKeyEnvironment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApiKeyEnvironment"
    ADD CONSTRAINT "ApiKeyEnvironment_pkey" PRIMARY KEY (id);


--
-- Name: ApiKey ApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_pkey" PRIMARY KEY (id);


--
-- Name: ContactAttributeKey ContactAttributeKey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContactAttributeKey"
    ADD CONSTRAINT "ContactAttributeKey_pkey" PRIMARY KEY (id);


--
-- Name: ContactAttribute ContactAttribute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContactAttribute"
    ADD CONSTRAINT "ContactAttribute_pkey" PRIMARY KEY (id);


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: DataMigration DataMigration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DataMigration"
    ADD CONSTRAINT "DataMigration_pkey" PRIMARY KEY (id);


--
-- Name: Display Display_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Display"
    ADD CONSTRAINT "Display_pkey" PRIMARY KEY (id);


--
-- Name: Environment Environment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Environment"
    ADD CONSTRAINT "Environment_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Invite Invite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_pkey" PRIMARY KEY (id);


--
-- Name: Language Language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Language"
    ADD CONSTRAINT "Language_pkey" PRIMARY KEY (id);


--
-- Name: Membership Membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_pkey" PRIMARY KEY ("userId", "organizationId");


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: ProjectTeam ProjectTeam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectTeam"
    ADD CONSTRAINT "ProjectTeam_pkey" PRIMARY KEY ("projectId", "teamId");


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: ResponseQuotaLink ResponseQuotaLink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseQuotaLink"
    ADD CONSTRAINT "ResponseQuotaLink_pkey" PRIMARY KEY ("responseId", "quotaId");


--
-- Name: Response Response_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Response"
    ADD CONSTRAINT "Response_pkey" PRIMARY KEY (id);


--
-- Name: Segment Segment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Segment"
    ADD CONSTRAINT "Segment_pkey" PRIMARY KEY (id);


--
-- Name: SurveyAttributeFilter SurveyAttributeFilter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyAttributeFilter"
    ADD CONSTRAINT "SurveyAttributeFilter_pkey" PRIMARY KEY (id);


--
-- Name: SurveyFollowUp SurveyFollowUp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyFollowUp"
    ADD CONSTRAINT "SurveyFollowUp_pkey" PRIMARY KEY (id);


--
-- Name: SurveyLanguage SurveyLanguage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyLanguage"
    ADD CONSTRAINT "SurveyLanguage_pkey" PRIMARY KEY ("languageId", "surveyId");


--
-- Name: SurveyQuota SurveyQuota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyQuota"
    ADD CONSTRAINT "SurveyQuota_pkey" PRIMARY KEY (id);


--
-- Name: SurveyTrigger SurveyTrigger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyTrigger"
    ADD CONSTRAINT "SurveyTrigger_pkey" PRIMARY KEY (id);


--
-- Name: Survey Survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Survey"
    ADD CONSTRAINT "Survey_pkey" PRIMARY KEY (id);


--
-- Name: Tag Tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tag"
    ADD CONSTRAINT "Tag_pkey" PRIMARY KEY (id);


--
-- Name: TagsOnResponses TagsOnResponses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TagsOnResponses"
    ADD CONSTRAINT "TagsOnResponses_pkey" PRIMARY KEY ("responseId", "tagId");


--
-- Name: TeamUser TeamUser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamUser"
    ADD CONSTRAINT "TeamUser_pkey" PRIMARY KEY ("teamId", "userId");


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Webhook Webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Webhook"
    ADD CONSTRAINT "Webhook_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: analytics_logs analytics_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_logs
    ADD CONSTRAINT analytics_logs_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Account_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Account_userId_idx" ON public."Account" USING btree ("userId");


--
-- Name: ActionClass_environmentId_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ActionClass_environmentId_created_at_idx" ON public."ActionClass" USING btree ("environmentId", created_at);


--
-- Name: ActionClass_key_environmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ActionClass_key_environmentId_key" ON public."ActionClass" USING btree (key, "environmentId");


--
-- Name: ActionClass_name_environmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ActionClass_name_environmentId_key" ON public."ActionClass" USING btree (name, "environmentId");


--
-- Name: ApiKeyEnvironment_apiKeyId_environmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ApiKeyEnvironment_apiKeyId_environmentId_key" ON public."ApiKeyEnvironment" USING btree ("apiKeyId", "environmentId");


--
-- Name: ApiKeyEnvironment_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ApiKeyEnvironment_environmentId_idx" ON public."ApiKeyEnvironment" USING btree ("environmentId");


--
-- Name: ApiKey_lookupHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ApiKey_lookupHash_key" ON public."ApiKey" USING btree ("lookupHash");


--
-- Name: ApiKey_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ApiKey_organizationId_idx" ON public."ApiKey" USING btree ("organizationId");


--
-- Name: ContactAttributeKey_environmentId_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ContactAttributeKey_environmentId_created_at_idx" ON public."ContactAttributeKey" USING btree ("environmentId", created_at);


--
-- Name: ContactAttributeKey_key_environmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ContactAttributeKey_key_environmentId_key" ON public."ContactAttributeKey" USING btree (key, "environmentId");


--
-- Name: ContactAttribute_attributeKeyId_value_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ContactAttribute_attributeKeyId_value_idx" ON public."ContactAttribute" USING btree ("attributeKeyId", value);


--
-- Name: ContactAttribute_contactId_attributeKeyId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ContactAttribute_contactId_attributeKeyId_key" ON public."ContactAttribute" USING btree ("contactId", "attributeKeyId");


--
-- Name: Contact_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Contact_environmentId_idx" ON public."Contact" USING btree ("environmentId");


--
-- Name: DataMigration_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DataMigration_name_key" ON public."DataMigration" USING btree (name);


--
-- Name: Display_contactId_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Display_contactId_created_at_idx" ON public."Display" USING btree ("contactId", created_at);


--
-- Name: Display_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Display_surveyId_idx" ON public."Display" USING btree ("surveyId");


--
-- Name: Environment_projectId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Environment_projectId_idx" ON public."Environment" USING btree ("projectId");


--
-- Name: Integration_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Integration_environmentId_idx" ON public."Integration" USING btree ("environmentId");


--
-- Name: Integration_type_environmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Integration_type_environmentId_key" ON public."Integration" USING btree (type, "environmentId");


--
-- Name: Invite_email_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invite_email_organizationId_idx" ON public."Invite" USING btree (email, "organizationId");


--
-- Name: Invite_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Invite_organizationId_idx" ON public."Invite" USING btree ("organizationId");


--
-- Name: Language_projectId_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Language_projectId_code_key" ON public."Language" USING btree ("projectId", code);


--
-- Name: Membership_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Membership_organizationId_idx" ON public."Membership" USING btree ("organizationId");


--
-- Name: Membership_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Membership_userId_idx" ON public."Membership" USING btree ("userId");


--
-- Name: ProjectTeam_teamId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectTeam_teamId_idx" ON public."ProjectTeam" USING btree ("teamId");


--
-- Name: Project_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Project_organizationId_idx" ON public."Project" USING btree ("organizationId");


--
-- Name: Project_organizationId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Project_organizationId_name_key" ON public."Project" USING btree ("organizationId", name);


--
-- Name: ResponseQuotaLink_quotaId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ResponseQuotaLink_quotaId_status_idx" ON public."ResponseQuotaLink" USING btree ("quotaId", status);


--
-- Name: Response_contactId_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Response_contactId_created_at_idx" ON public."Response" USING btree ("contactId", created_at);


--
-- Name: Response_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Response_created_at_idx" ON public."Response" USING btree (created_at);


--
-- Name: Response_displayId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Response_displayId_key" ON public."Response" USING btree ("displayId");


--
-- Name: Response_surveyId_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Response_surveyId_created_at_idx" ON public."Response" USING btree ("surveyId", created_at);


--
-- Name: Response_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Response_surveyId_idx" ON public."Response" USING btree ("surveyId");


--
-- Name: Response_surveyId_singleUseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Response_surveyId_singleUseId_key" ON public."Response" USING btree ("surveyId", "singleUseId");


--
-- Name: Segment_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Segment_environmentId_idx" ON public."Segment" USING btree ("environmentId");


--
-- Name: Segment_environmentId_title_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Segment_environmentId_title_key" ON public."Segment" USING btree ("environmentId", title);


--
-- Name: SurveyAttributeFilter_attributeKeyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyAttributeFilter_attributeKeyId_idx" ON public."SurveyAttributeFilter" USING btree ("attributeKeyId");


--
-- Name: SurveyAttributeFilter_surveyId_attributeKeyId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SurveyAttributeFilter_surveyId_attributeKeyId_key" ON public."SurveyAttributeFilter" USING btree ("surveyId", "attributeKeyId");


--
-- Name: SurveyAttributeFilter_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyAttributeFilter_surveyId_idx" ON public."SurveyAttributeFilter" USING btree ("surveyId");


--
-- Name: SurveyLanguage_languageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyLanguage_languageId_idx" ON public."SurveyLanguage" USING btree ("languageId");


--
-- Name: SurveyLanguage_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyLanguage_surveyId_idx" ON public."SurveyLanguage" USING btree ("surveyId");


--
-- Name: SurveyQuota_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyQuota_surveyId_idx" ON public."SurveyQuota" USING btree ("surveyId");


--
-- Name: SurveyQuota_surveyId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SurveyQuota_surveyId_name_key" ON public."SurveyQuota" USING btree ("surveyId", name);


--
-- Name: SurveyTrigger_surveyId_actionClassId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SurveyTrigger_surveyId_actionClassId_key" ON public."SurveyTrigger" USING btree ("surveyId", "actionClassId");


--
-- Name: SurveyTrigger_surveyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SurveyTrigger_surveyId_idx" ON public."SurveyTrigger" USING btree ("surveyId");


--
-- Name: Survey_environmentId_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Survey_environmentId_updated_at_idx" ON public."Survey" USING btree ("environmentId", updated_at);


--
-- Name: Survey_segmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Survey_segmentId_idx" ON public."Survey" USING btree ("segmentId");


--
-- Name: Tag_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Tag_environmentId_idx" ON public."Tag" USING btree ("environmentId");


--
-- Name: Tag_environmentId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Tag_environmentId_name_key" ON public."Tag" USING btree ("environmentId", name);


--
-- Name: TagsOnResponses_responseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TagsOnResponses_responseId_idx" ON public."TagsOnResponses" USING btree ("responseId");


--
-- Name: TeamUser_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TeamUser_userId_idx" ON public."TeamUser" USING btree ("userId");


--
-- Name: Team_organizationId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team_organizationId_name_key" ON public."Team" USING btree ("organizationId", name);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Webhook_environmentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Webhook_environmentId_idx" ON public."Webhook" USING btree ("environmentId");


--
-- Name: analytics_logs_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_logs_created_at_idx ON public.analytics_logs USING btree (created_at);


--
-- Name: analytics_logs_event_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_logs_event_idx ON public.analytics_logs USING btree (event);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActionClass ActionClass_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionClass"
    ADD CONSTRAINT "ActionClass_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ApiKeyEnvironment ApiKeyEnvironment_apiKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApiKeyEnvironment"
    ADD CONSTRAINT "ApiKeyEnvironment_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES public."ApiKey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ApiKeyEnvironment ApiKeyEnvironment_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApiKeyEnvironment"
    ADD CONSTRAINT "ApiKeyEnvironment_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ApiKey ApiKey_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactAttributeKey ContactAttributeKey_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContactAttributeKey"
    ADD CONSTRAINT "ContactAttributeKey_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactAttribute ContactAttribute_attributeKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContactAttribute"
    ADD CONSTRAINT "ContactAttribute_attributeKeyId_fkey" FOREIGN KEY ("attributeKeyId") REFERENCES public."ContactAttributeKey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactAttribute ContactAttribute_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ContactAttribute"
    ADD CONSTRAINT "ContactAttribute_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Contact Contact_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Display Display_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Display"
    ADD CONSTRAINT "Display_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Display Display_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Display"
    ADD CONSTRAINT "Display_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Environment Environment_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Environment"
    ADD CONSTRAINT "Environment_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Integration Integration_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invite Invite_acceptorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_acceptorId_fkey" FOREIGN KEY ("acceptorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invite Invite_creatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_creatorId_fkey" FOREIGN KEY ("creatorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invite Invite_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Language Language_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Language"
    ADD CONSTRAINT "Language_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Membership Membership_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Membership Membership_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectTeam ProjectTeam_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectTeam"
    ADD CONSTRAINT "ProjectTeam_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectTeam ProjectTeam_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectTeam"
    ADD CONSTRAINT "ProjectTeam_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ResponseQuotaLink ResponseQuotaLink_quotaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseQuotaLink"
    ADD CONSTRAINT "ResponseQuotaLink_quotaId_fkey" FOREIGN KEY ("quotaId") REFERENCES public."SurveyQuota"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ResponseQuotaLink ResponseQuotaLink_responseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResponseQuotaLink"
    ADD CONSTRAINT "ResponseQuotaLink_responseId_fkey" FOREIGN KEY ("responseId") REFERENCES public."Response"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Response Response_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Response"
    ADD CONSTRAINT "Response_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Response Response_displayId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Response"
    ADD CONSTRAINT "Response_displayId_fkey" FOREIGN KEY ("displayId") REFERENCES public."Display"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Response Response_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Response"
    ADD CONSTRAINT "Response_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Segment Segment_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Segment"
    ADD CONSTRAINT "Segment_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyAttributeFilter SurveyAttributeFilter_attributeKeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyAttributeFilter"
    ADD CONSTRAINT "SurveyAttributeFilter_attributeKeyId_fkey" FOREIGN KEY ("attributeKeyId") REFERENCES public."ContactAttributeKey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyAttributeFilter SurveyAttributeFilter_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyAttributeFilter"
    ADD CONSTRAINT "SurveyAttributeFilter_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyFollowUp SurveyFollowUp_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyFollowUp"
    ADD CONSTRAINT "SurveyFollowUp_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyLanguage SurveyLanguage_languageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyLanguage"
    ADD CONSTRAINT "SurveyLanguage_languageId_fkey" FOREIGN KEY ("languageId") REFERENCES public."Language"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyLanguage SurveyLanguage_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyLanguage"
    ADD CONSTRAINT "SurveyLanguage_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyQuota SurveyQuota_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyQuota"
    ADD CONSTRAINT "SurveyQuota_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyTrigger SurveyTrigger_actionClassId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyTrigger"
    ADD CONSTRAINT "SurveyTrigger_actionClassId_fkey" FOREIGN KEY ("actionClassId") REFERENCES public."ActionClass"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SurveyTrigger SurveyTrigger_surveyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SurveyTrigger"
    ADD CONSTRAINT "SurveyTrigger_surveyId_fkey" FOREIGN KEY ("surveyId") REFERENCES public."Survey"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Survey Survey_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Survey"
    ADD CONSTRAINT "Survey_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Survey Survey_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Survey"
    ADD CONSTRAINT "Survey_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Survey Survey_segmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Survey"
    ADD CONSTRAINT "Survey_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES public."Segment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tag Tag_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tag"
    ADD CONSTRAINT "Tag_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TagsOnResponses TagsOnResponses_responseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TagsOnResponses"
    ADD CONSTRAINT "TagsOnResponses_responseId_fkey" FOREIGN KEY ("responseId") REFERENCES public."Response"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TagsOnResponses TagsOnResponses_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TagsOnResponses"
    ADD CONSTRAINT "TagsOnResponses_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tag"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TeamUser TeamUser_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamUser"
    ADD CONSTRAINT "TeamUser_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TeamUser TeamUser_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamUser"
    ADD CONSTRAINT "TeamUser_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Team Team_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Webhook Webhook_environmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Webhook"
    ADD CONSTRAINT "Webhook_environmentId_fkey" FOREIGN KEY ("environmentId") REFERENCES public."Environment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict lBEXqOXmmHcfqcgI2pDAaGRTAniCfZPW0cCdhf3d0UIeP68bkq6qrnkoc3Hh66j

